prompt --application/pages/page_00026
begin
--   Manifest
--     PAGE: 00026
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.2'
,p_default_workspace_id=>8391952292696292789
,p_default_application_id=>74555
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BANCHONWORKSPACE'
);
wwv_flow_api.create_page(
 p_id=>26
,p_user_interface_id=>wwv_flow_api.id(26165657796355479380)
,p_name=>'Detalles de Lugar'
,p_alias=>'DETALLES-DE-LUGAR'
,p_page_mode=>'MODAL'
,p_step_title=>'Detalles de Lugar'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_api.id(26165524910282479292)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_last_updated_by=>'HBANCHONG@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20210825034600'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(28711149425839015933)
,p_plug_name=>unistr('Res\00FAmen de: &P26_NOMBRE_LUGAR.')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(26165568079583479315)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(28711148523710015924)
,p_name=>'Resumen de: &P26_NOMBRE_LUGAR.'
,p_parent_plug_id=>wwv_flow_api.id(28711149425839015933)
,p_template=>wwv_flow_api.id(26165568079583479315)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--rightAligned'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT COUNT(ID_CASO) as "Casos Registrados"',
'FROM CASO C',
'INNER JOIN LUGAR L ON L.ID_LUGAR = C.ID_LUGAR',
'WHERE L.ID_LUGAR = :P26_ID_LUGAR',
'GROUP BY L.NOMBRE_LUGAR'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(26165601117775479332)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Actualmente no se han registrado datos en este lugar.'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(28711149298814015931)
,p_query_column_id=>1
,p_column_alias=>'Casos Registrados'
,p_column_display_sequence=>10
,p_column_heading=>'Casos Registrados'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(28711149738246015936)
,p_name=>'Incidentes registrados'
,p_parent_plug_id=>wwv_flow_api.id(28711149425839015933)
,p_template=>wwv_flow_api.id(26165568079583479315)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--rightAligned'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    T.NOMBRE_TIPO_INCIDENTE as "Tipo de Incidente",',
'    COUNT(ID_CASO) as "Casos Registrados"',
'FROM TIPO_INCIDENTE T',
'INNER JOIN CASO C ON C.ID_TIPO_INCIDENTE = T.ID_TIPO_INCIDENTE',
'WHERE C.ID_LUGAR = :P26_ID_LUGAR',
'GROUP BY T.NOMBRE_TIPO_INCIDENTE'))
,p_display_when_condition=>'P26_CASOS'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(26165603107750479333)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(28711150097391015939)
,p_query_column_id=>1
,p_column_alias=>'Tipo de Incidente'
,p_column_display_sequence=>10
,p_column_heading=>'Tipo de Incidente'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(28711150139835015940)
,p_query_column_id=>2
,p_column_alias=>'Casos Registrados'
,p_column_display_sequence=>20
,p_column_heading=>'Casos Registrados'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28711148877334015927)
,p_name=>'P26_ID_LUGAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(28711149425839015933)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28711149375437015932)
,p_name=>'P26_NOMBRE_LUGAR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(28711149425839015933)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NOMBRE_LUGAR',
'FROM LUGAR',
'WHERE ID_LUGAR = :P26_ID_LUGAR'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28711150270393015941)
,p_name=>'P26_CASOS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(28711149425839015933)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT COUNT(ID_CASO)',
'FROM CASO',
'INNER JOIN LUGAR ON LUGAR.ID_LUGAR = CASO.ID_LUGAR',
'WHERE LUGAR.ID_LUGAR = :P26_ID_LUGAR',
'GROUP BY LUGAR.NOMBRE_LUGAR;'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.component_end;
end;
/
