prompt --application/pages/page_00100
begin
--   Manifest
--     PAGE: 00100
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.2'
,p_default_workspace_id=>8391952292696292789
,p_default_application_id=>74555
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BANCHONWORKSPACE'
);
wwv_flow_api.create_page(
 p_id=>100
,p_user_interface_id=>wwv_flow_api.id(26165657796355479380)
,p_name=>unistr('Cargar Informaci\00F3n de Lugar')
,p_alias=>unistr('CARGAR-INFORMACI\00D3N-DE-LUGAR')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Cargar Informaci\00F3n de Lugar')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(26165660230926479396)
,p_last_updated_by=>'HBANCHONG@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20210831154145'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29597251058857878804)
,p_plug_name=>'Barra de Botones'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_api.id(26165537923214479300)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29597251340341878807)
,p_plug_name=>'Origen de Datos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(26165568079583479315)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29597251423152878808)
,p_plug_name=>'Cargar Archivo'
,p_parent_plug_id=>wwv_flow_api.id(29597251340341878807)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(26165536920310479299)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P100_FILE'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29597251751949878811)
,p_plug_name=>'Archivo Cargado'
,p_parent_plug_id=>wwv_flow_api.id(29597251340341878807)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(26165536920310479299)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P100_FILE'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(29597251103960878805)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(29597251058857878804)
,p_button_name=>'CLEAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(26165633243575479353)
,p_button_image_alt=>'Borrar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(29597251208547878806)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(29597251058857878804)
,p_button_name=>'LOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(26165633374392479353)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cargar Datos'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-download'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(29597251671567878810)
,p_name=>'P100_FILE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(29597251423152878808)
,p_prompt=>'Cargar Archivo'
,p_display_as=>'NATIVE_FILE'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_api.id(26165630350366479349)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'DROPZONE_BLOCK'
,p_attribute_14=>'Formato soportados JSON.'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(29597251827288878812)
,p_name=>'P100_FILE_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(29597251751949878811)
,p_prompt=>'Archivo Cargado'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(26165630668626479351)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(29597252154261878815)
,p_computation_sequence=>10
,p_computation_item=>'P100_FILE_NAME'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select filename',
'  from apex_application_temp_files ',
' where name = :P100_FILE'))
,p_compute_when=>'P100_FILE'
,p_compute_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(29597252267878878816)
,p_validation_name=>'Tipo de Archivo Valido'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if apex_data_parser.assert_file_type(',
'       p_file_name => :P100_FILE_NAME,',
'       p_file_type => apex_data_parser.c_file_type_json )',
'then',
'    return true;',
'else',
'    :P100_FILE := null;',
'    return false;',
'end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('Tipo de archivo no v\00E1lido. Los tipos de archivo soportados son JSON.')
,p_associated_item=>wwv_flow_api.id(29597251671567878810)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(29597251922247878813)
,p_name=>'Cargar Archivo'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P100_FILE'
,p_condition_element=>'P100_FILE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(29597252033024878814)
,p_event_id=>wwv_flow_api.id(29597251922247878813)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(29597252393477878817)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Cargar Informaci\00F3n')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    uca_lugar_load(',
'        p_file_name   => :P100_FILE);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'No se pudo realizar la carga de datos.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(29597251208547878806)
,p_process_success_message=>unistr('Se carg\00F3 la informaci\00F3n correctamente.')
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(29597252867597878822)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>unistr('Borrar Cach\00E9')
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>':REQUEST = ''CLEAR'''
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
);
wwv_flow_api.component_end;
end;
/
