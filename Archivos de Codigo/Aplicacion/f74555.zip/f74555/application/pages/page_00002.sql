prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.2'
,p_default_workspace_id=>8391952292696292789
,p_default_application_id=>74555
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BANCHONWORKSPACE'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(26165657796355479380)
,p_name=>'Mapa de Casos'
,p_alias=>'MAPA-DE-CASOS'
,p_step_title=>'Mapa de Casos'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'HBANCHONG@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20210829195843'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(28716231170513696053)
,p_plug_name=>'Mapa de Casos'
,p_region_name=>'casos-mapa-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(26165537103536479299)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_LUGAR,',
'       NOMBRE_LUGAR,',
'       GEOMETRIA',
'  from LUGAR'))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_map_region(
 p_id=>wwv_flow_api.id(28716231442976696057)
,p_region_id=>wwv_flow_api.id(28716231170513696053)
,p_height=>648
,p_tilelayer_type=>'CUSTOM'
,p_tilelayer_name_default=>'osm-positron'
,p_tilelayer_name_dark=>'osm-dark-matter'
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'-89.2359082'
,p_init_position_lat_static=>'13.6807545'
,p_init_zoomlevel_static=>'18'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'MOUSEWHEEL_ZOOM:SCALE_BAR:INFINITE_MAP'
);
wwv_flow_api.create_map_region_layer(
 p_id=>wwv_flow_api.id(28716231985718696058)
,p_map_region_id=>wwv_flow_api.id(28716231442976696057)
,p_name=>'Lugares'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_pk_column=>'ID_LUGAR'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRIA'
,p_stroke_color=>'#ffffff'
,p_fill_color=>'#ff0000'
,p_fill_opacity=>.8
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_point_svg_shape_scale=>'2'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'<strong>&NOMBRE_LUGAR.</strong>'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.::P26_ID_LUGAR:&ID_LUGAR.'
,p_allow_hide=>true
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29597252410398878818)
,p_plug_name=>'Barra de Botones'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_api.id(26165537923214479300)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(29597252773548878821)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(29597252410398878818)
,p_button_name=>'Load-Data'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(26165633243575479353)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Cargar Informaci\00F3n')
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(20097299791459677433)
,p_name=>'On Click Point'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(28716231170513696053)
,p_bind_type=>'bind'
,p_bind_event_type=>'NATIVE_MAP_REGION|REGION TYPE|spatialmapobjectclick'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(20097299865737677434)
,p_event_id=>wwv_flow_api.id(20097299791459677433)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const { lng, lat } = this.data;',
'',
'apex.region("casos-mapa-region").call( "getMapObject" ).flyTo({ ',
'    center: [ lng, lat ],',
'    screenSpeed: 0.5',
'});'))
);
wwv_flow_api.component_end;
end;
/
