prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.2'
,p_default_workspace_id=>8391952292696292789
,p_default_application_id=>74555
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BANCHONWORKSPACE'
);
wwv_flow_api.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_api.id(26165657796355479380)
,p_name=>'Inicio'
,p_alias=>'HOME'
,p_step_title=>'Sistema de Casos UCA'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'HBANCHONG@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20210821233951'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(23207531445651038204)
,p_plug_name=>unistr('Estad\00EDsticas Generales')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(26165568079583479315)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(23207531752918038207)
,p_name=>'Casos Registrados en &P1_ANIO_ACTUAL.'
,p_parent_plug_id=>wwv_flow_api.id(23207531445651038204)
,p_template=>wwv_flow_api.id(26165568079583479315)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--large:t-BadgeList--circular:t-BadgeList--fixed:t-Report--hideNoPagination'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT count(ID_CASO)',
'FROM CASO',
'WHERE EXTRACT(YEAR FROM FECHA_CASO) = EXTRACT(YEAR FROM sysdate);'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(26165580130609479321)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No se han encontrado datos.'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23207532097176038210)
,p_query_column_id=>1
,p_column_alias=>'COUNT(ID_CASO)'
,p_column_display_sequence=>10
,p_column_heading=>'Casos Registrados en &P1_ANIO_ACTUAL.'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(23207532175875038211)
,p_name=>'Casos registrados en el mes de &P1_MES_ACTUAL.'
,p_parent_plug_id=>wwv_flow_api.id(23207531445651038204)
,p_template=>wwv_flow_api.id(26165568079583479315)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--large:t-BadgeList--circular:t-BadgeList--fixed:t-Report--hideNoPagination'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT count(ID_CASO)',
'FROM CASO',
'WHERE EXTRACT(MONTH FROM FECHA_CASO) = EXTRACT(MONTH FROM sysdate)',
'AND EXTRACT(YEAR FROM FECHA_CASO) = EXTRACT(YEAR FROM sysdate);'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(26165580130609479321)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No se han encontrado datos.'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23207532284891038212)
,p_query_column_id=>1
,p_column_alias=>'COUNT(ID_CASO)'
,p_column_display_sequence=>10
,p_column_heading=>'Casos Registrados en el Mes de &P1_MES_ACTUAL.'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(23207532327423038213)
,p_name=>'Total de Casos Registrados'
,p_parent_plug_id=>wwv_flow_api.id(23207531445651038204)
,p_template=>wwv_flow_api.id(26165568079583479315)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--large:t-BadgeList--circular:t-BadgeList--fixed:t-Report--hideNoPagination'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT count(ID_CASO)',
'FROM CASO'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(26165580130609479321)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No se han encontrado datos.'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23207532414062038214)
,p_query_column_id=>1
,p_column_alias=>'COUNT(ID_CASO)'
,p_column_display_sequence=>10
,p_column_heading=>'Total de Casos Registrados'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(23207532681254038216)
,p_plug_name=>unistr('Gr\00E1ficas Principales')
,p_region_template_options=>'#DEFAULT#:js-headingLevel-1:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(26165568079583479315)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(23207532775357038217)
,p_plug_name=>'Accidentes Registrados'
,p_parent_plug_id=>wwv_flow_api.id(23207532681254038216)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(26165568079583479315)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(23207532839611038218)
,p_region_id=>wwv_flow_api.id(23207532775357038217)
,p_chart_type=>'bar'
,p_height=>'400'
,p_animation_on_display=>'alphaFade'
,p_animation_on_data_change=>'slideToLeft'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>false
,p_show_value=>true
,p_legend_rendered=>'off'
,p_no_data_found_message=>'No se han encontrado datos.'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(23207532989813038219)
,p_chart_id=>wwv_flow_api.id(23207532839611038218)
,p_seq=>10
,p_name=>'Incidentes Serie'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT T.NOMBRE_TIPO_INCIDENTE as Incidente,',
'    COUNT(C.ID_CASO) as Casos',
'FROM CASO C',
'INNER JOIN TIPO_INCIDENTE T ON T.ID_TIPO_INCIDENTE = C.ID_TIPO_INCIDENTE',
'GROUP BY T.NOMBRE_TIPO_INCIDENTE'))
,p_series_name_column_name=>'INCIDENTE'
,p_items_value_column_name=>'CASOS'
,p_items_label_column_name=>'INCIDENTE'
,p_assigned_to_y2=>'on'
,p_items_label_rendered=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(23207533070010038220)
,p_chart_id=>wwv_flow_api.id(23207532839611038218)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(23207533130133038221)
,p_chart_id=>wwv_flow_api.id(23207532839611038218)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(23207533212955038222)
,p_chart_id=>wwv_flow_api.id(23207532839611038218)
,p_axis=>'y2'
,p_is_rendered=>'on'
,p_title=>'Casos'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_step=>1
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_split_dual_y=>'auto'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(23207533370373038223)
,p_plug_name=>'Accidentes por Lugar'
,p_parent_plug_id=>wwv_flow_api.id(23207532681254038216)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(26165568079583479315)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(23207533425949038224)
,p_region_id=>wwv_flow_api.id(23207533370373038223)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'alphaFade'
,p_animation_on_data_change=>'slideToRight'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlightAndExplode'
,p_no_data_found_message=>'No se han encontrado datos.'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(23207533554860038225)
,p_chart_id=>wwv_flow_api.id(23207533425949038224)
,p_seq=>10
,p_name=>'Lugar Series'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT L.NOMBRE_LUGAR as Lugar,',
'    COUNT(C.ID_CASO) as Casos',
'FROM CASO C',
'INNER JOIN LUGAR L ON L.ID_LUGAR = C.ID_LUGAR',
'GROUP BY L.NOMBRE_LUGAR'))
,p_series_name_column_name=>'LUGAR'
,p_items_value_column_name=>'CASOS'
,p_items_label_column_name=>'LUGAR'
,p_items_label_rendered=>true
,p_items_label_position=>'center'
,p_items_label_display_as=>'VALUE'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(23207533835151038228)
,p_plug_name=>unistr('Casos por A\00F1o')
,p_parent_plug_id=>wwv_flow_api.id(23207532681254038216)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(26165568079583479315)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(23207533957058038229)
,p_region_id=>wwv_flow_api.id(23207533835151038228)
,p_chart_type=>'donut'
,p_height=>'400'
,p_animation_on_display=>'alphaFade'
,p_animation_on_data_change=>'slideToLeft'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlightAndExplode'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(23207534003319038230)
,p_chart_id=>wwv_flow_api.id(23207533957058038229)
,p_seq=>10
,p_name=>unistr('A\00F1o Series')
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT COUNT(C.ID_CASO) as Casos,',
unistr('    EXTRACT(YEAR FROM C.FECHA_CASO) as A\00F1o'),
'FROM CASO C',
'WHERE C.FECHA_CASO > SYSDATE - INTERVAL ''5'' YEAR',
'GROUP BY EXTRACT(YEAR FROM C.FECHA_CASO)',
unistr('ORDER BY A\00F1o')))
,p_series_name_column_name=>unistr('A\00D1O')
,p_items_value_column_name=>'CASOS'
,p_items_label_column_name=>unistr('A\00D1O')
,p_items_label_rendered=>true
,p_items_label_position=>'center'
,p_items_label_display_as=>'VALUE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(23207531563027038205)
,p_name=>'P1_ANIO_ACTUAL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(23207531445651038204)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT EXTRACT(YEAR FROM sysdate)',
'FROM dual;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(23207531602717038206)
,p_name=>'P1_MES_ACTUAL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(23207531445651038204)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT to_char(sysdate, ''Month'')',
'FROM dual;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.component_end;
end;
/
