prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.2'
,p_default_workspace_id=>8391952292696292789
,p_default_application_id=>74555
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BANCHONWORKSPACE'
);
wwv_flow_api.create_page(
 p_id=>0
,p_user_interface_id=>wwv_flow_api.id(26165657796355479380)
,p_name=>unistr('P\00E1gina Global - Escritorio')
,p_step_title=>unistr('P\00E1gina Global - Escritorio')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'D'
,p_last_updated_by=>'HBANCHONG@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20210904041027'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29597255483585878848)
,p_plug_name=>'Footer'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(26165537103536479299)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_05'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="footer-apex">Desarrollado con ',
'  <span class="fa fa-heart">',
'    <span class="u-VisuallyHidden">amor</span>',
'  </span> ',
'  utilizando <a href="https://apex.oracle.com/" target="_blank" title="Oracle Application Express">Oracle APEX</a>',
'</span>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.component_end;
end;
/
