prompt --application/pages/page_00034
begin
--   Manifest
--     PAGE: 00034
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.2'
,p_default_workspace_id=>8391952292696292789
,p_default_application_id=>74555
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BANCHONWORKSPACE'
);
wwv_flow_api.create_page(
 p_id=>34
,p_user_interface_id=>wwv_flow_api.id(26165657796355479380)
,p_name=>unistr('Confirmaci\00F3n de Caso con Afectado')
,p_alias=>unistr('CONFIRMACI\00D3N-DE-CASO-CON-AFECTADO')
,p_step_title=>unistr('Confirmaci\00F3n de Caso con Afectado')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'HBANCHONG@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20210831135158'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(26180774943637701559)
,p_plug_name=>unistr('Confirmaci\00F3n de Caso con Afectado')
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(26165578651845479319)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(26180758324050701548)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(26165628925825479349)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(26180775062284701559)
,p_plug_name=>unistr('Confirmaci\00F3n de Caso con Afectado')
,p_parent_plug_id=>wwv_flow_api.id(26180774943637701559)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(26165536920310479299)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'AFECTADO_X_CASO'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(28707362364106640229)
,p_name=>unistr('Res\00FAmen de Afectado')
,p_parent_plug_id=>wwv_flow_api.id(26180774943637701559)
,p_template=>wwv_flow_api.id(26165568079583479315)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--rightAligned:t-Report--hideNoPagination'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_AFECTADO,',
'       ID_VISITANTE,',
'       ID_EMPLEADO,',
'       ID_TIPO_AFECTADO',
'  from AFECTADO',
' where "ID_AFECTADO" = :P34_ID_AFECTADO;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(26165601117775479332)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(28707362703977640233)
,p_query_column_id=>1
,p_column_alias=>'ID_AFECTADO'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(28707363386819640239)
,p_query_column_id=>2
,p_column_alias=>'ID_VISITANTE'
,p_column_display_sequence=>20
,p_column_heading=>'Visitante'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(26179485494677374482)
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(28707363434775640240)
,p_query_column_id=>3
,p_column_alias=>'ID_EMPLEADO'
,p_column_display_sequence=>30
,p_column_heading=>'Empleado'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(26179496607222377944)
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(28707363541437640241)
,p_query_column_id=>4
,p_column_alias=>'ID_TIPO_AFECTADO'
,p_column_display_sequence=>40
,p_column_heading=>'Tipo de Afectado'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(26173362177025742007)
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(28707363620117640242)
,p_name=>unistr('Res\00FAmen de Caso')
,p_parent_plug_id=>wwv_flow_api.id(26180774943637701559)
,p_template=>wwv_flow_api.id(26165568079583479315)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--rightAligned:t-Report--hideNoPagination'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_CASO,',
'       FECHA_CASO,',
'       DESCRIPCION_CASO,',
'       ID_ESTADO,',
'       ID_LUGAR,',
'       ID_TIPO_INCIDENTE',
'  from CASO',
' where "ID_CASO" = :P34_ID_CASO;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(26165601117775479332)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(28707364175657640247)
,p_query_column_id=>1
,p_column_alias=>'ID_CASO'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(28707364294392640248)
,p_query_column_id=>2
,p_column_alias=>'FECHA_CASO'
,p_column_display_sequence=>20
,p_column_heading=>'Fecha del Caso'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(28707364373255640249)
,p_query_column_id=>3
,p_column_alias=>'DESCRIPCION_CASO'
,p_column_display_sequence=>30
,p_column_heading=>unistr('Descripci\00F3n del Caso')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(28707364416958640250)
,p_query_column_id=>4
,p_column_alias=>'ID_ESTADO'
,p_column_display_sequence=>40
,p_column_heading=>'Estado del Caso'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(26173911021940744886)
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(28711146297829015901)
,p_query_column_id=>5
,p_column_alias=>'ID_LUGAR'
,p_column_display_sequence=>50
,p_column_heading=>'Lugar'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(26173317710641731392)
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(28711146392634015902)
,p_query_column_id=>6
,p_column_alias=>'ID_TIPO_INCIDENTE'
,p_column_display_sequence=>60
,p_column_heading=>'Tipo de Incidente'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(26173356680046737696)
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(26180776711072701560)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(26180774943637701559)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(26165633243575479353)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:::'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(26180776858476701560)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(26180774943637701559)
,p_button_name=>'FINISH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(26165633243575479353)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Terminar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(26180776951037701560)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(26180774943637701559)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(26165632512882479352)
,p_button_image_alt=>'Anterior'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(28711146644073015905)
,p_branch_name=>'Terminar Proceso'
,p_branch_action=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(26180776858476701560)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(26180777771525701560)
,p_branch_name=>unistr('Ir a P\00E1gina 33')
,p_branch_action=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(26180776951037701560)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(26180776404250701559)
,p_name=>'P34_ID_CASO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(26180775062284701559)
,p_item_source_plug_id=>wwv_flow_api.id(26180775062284701559)
,p_source=>'ID_CASO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28707361876396640224)
,p_name=>'P34_ID_AFECTADO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(26180775062284701559)
,p_item_source_plug_id=>wwv_flow_api.id(26180775062284701559)
,p_source=>'ID_AFECTADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(28707362072544640226)
,p_name=>'P34_ID_AFECTADO_X_CASO'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(26180775062284701559)
,p_item_source_plug_id=>wwv_flow_api.id(26180775062284701559)
,p_source=>'ID_AFECTADO_X_CASO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(28707362459098640230)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(26180775062284701559)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('Proceso de Inserci\00F3n de Afectado_X_Caso')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>unistr('Se registr\00F3 exitosamente el caso.')
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(28707361913451640225)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(26180775062284701559)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Inicializar pantalla Confirmaci\00F3n de Caso con Afectado')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
