prompt --application/pages/page_00025
begin
--   Manifest
--     PAGE: 00025
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.2'
,p_default_workspace_id=>8391952292696292789
,p_default_application_id=>74555
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BANCHONWORKSPACE'
);
wwv_flow_api.create_page(
 p_id=>25
,p_user_interface_id=>wwv_flow_api.id(26165657796355479380)
,p_name=>'Detalles de Caso'
,p_alias=>'DETALLES-DE-CASO'
,p_page_mode=>'MODAL'
,p_step_title=>'Detalles de Caso'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'HBANCHONG@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20210904060541'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(23207535432458038244)
,p_plug_name=>'Caso &P25_ID_CASO.'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(26165568079583479315)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(23207535645465038246)
,p_name=>unistr('Informaci\00F3n Principal del Caso')
,p_parent_plug_id=>wwv_flow_api.id(23207535432458038244)
,p_template=>wwv_flow_api.id(26165568079583479315)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--fixedLabelLarge:t-AVPList--rightAligned:t-Report--hideNoPagination'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select C.FECHA_CASO,',
'       C.DESCRIPCION_CASO,',
'       C.ID_ESTADO,',
'       C.ID_LUGAR',
'  from CASO C',
'  where C.ID_CASO = :P25_ID_CASO;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(26165601117775479332)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23207535905986038249)
,p_query_column_id=>1
,p_column_alias=>'FECHA_CASO'
,p_column_display_sequence=>10
,p_column_heading=>'Fecha del Caso'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(23207536040544038250)
,p_query_column_id=>2
,p_column_alias=>'DESCRIPCION_CASO'
,p_column_display_sequence=>20
,p_column_heading=>unistr('Descripci\00F3n del Caso')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(26179056746037305201)
,p_query_column_id=>3
,p_column_alias=>'ID_ESTADO'
,p_column_display_sequence=>30
,p_column_heading=>'Estado del Caso'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(26173911021940744886)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(26179056811435305202)
,p_query_column_id=>4
,p_column_alias=>'ID_LUGAR'
,p_column_display_sequence=>40
,p_column_heading=>'Lugar'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(26173317710641731392)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(23207535718316038247)
,p_name=>unistr('Informaci\00F3n del Empleado')
,p_parent_plug_id=>wwv_flow_api.id(23207535432458038244)
,p_template=>wwv_flow_api.id(26165568079583479315)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--rightAligned:t-Report--hideNoPagination'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'       A.ID_EMPLEADO,',
'       E.CODIGO_EMPLEADO,',
'       E.ID_UNIDAD',
'  from CASO C',
'  inner join AFECTADO_X_CASO F',
'  on F.ID_CASO = C.ID_CASO',
'  inner join AFECTADO A',
'  on A.ID_AFECTADO = F.ID_AFECTADO',
'  left join EMPLEADO E',
'  on E.ID_EMPLEADO = A.ID_EMPLEADO',
'  where C.ID_CASO = :P25_ID_CASO;'))
,p_display_when_condition=>'P25_ID_TIPO_AFECTADO'
,p_display_when_cond2=>'1'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(26165601117775479332)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(26179057199564305205)
,p_query_column_id=>1
,p_column_alias=>'ID_EMPLEADO'
,p_column_display_sequence=>30
,p_column_heading=>'Nombre del Empleado'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(26179496607222377944)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(28711150431345015943)
,p_query_column_id=>2
,p_column_alias=>'CODIGO_EMPLEADO'
,p_column_display_sequence=>40
,p_column_heading=>unistr('C\00F3digo del Empleado')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(31612925248120200402)
,p_query_column_id=>3
,p_column_alias=>'ID_UNIDAD'
,p_column_display_sequence=>50
,p_column_heading=>'Unidad del Empleado'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(31616999139787364409)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(23207535832710038248)
,p_name=>unistr('Informaci\00F3n del Incidente')
,p_parent_plug_id=>wwv_flow_api.id(23207535432458038244)
,p_template=>wwv_flow_api.id(26165568079583479315)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--rightAligned:t-Report--hideNoPagination'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select C.ID_TIPO_INCIDENTE,',
'       T.ID_CATEGORIA_INCIDENTE',
'  from CASO C',
'  inner join TIPO_INCIDENTE T',
'  on T.ID_TIPO_INCIDENTE = C.ID_TIPO_INCIDENTE',
'  where C.ID_CASO = :P25_ID_CASO;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(26165601117775479332)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(26179057259329305206)
,p_query_column_id=>1
,p_column_alias=>'ID_TIPO_INCIDENTE'
,p_column_display_sequence=>10
,p_column_heading=>'Tipo de Incidente'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(26173356680046737696)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(26179057344281305207)
,p_query_column_id=>2
,p_column_alias=>'ID_CATEGORIA_INCIDENTE'
,p_column_display_sequence=>20
,p_column_heading=>unistr('Categor\00EDa del Incidente')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(26177278178432205089)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(29597254076153878834)
,p_name=>unistr('Informaci\00F3n del Visitante')
,p_parent_plug_id=>wwv_flow_api.id(23207535432458038244)
,p_template=>wwv_flow_api.id(26165568079583479315)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--rightAligned:t-Report--hideNoPagination'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    A.ID_VISITANTE,',
'    V.MOTIVO_VISITANTE',
'FROM CASO C',
'INNER JOIN AFECTADO_X_CASO F',
'ON F.ID_CASO = C.ID_CASO',
'INNER JOIN AFECTADO A',
'ON A.ID_AFECTADO = F.ID_AFECTADO',
'LEFT JOIN VISITANTE V',
'ON V.ID_VISITANTE = A.ID_VISITANTE',
'WHERE C.ID_CASO = :P25_ID_CASO;',
'',
'',
'',
'',
'',
''))
,p_display_when_condition=>'P25_ID_TIPO_AFECTADO'
,p_display_when_cond2=>'2'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(26165601117775479332)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(29597254251299878836)
,p_query_column_id=>1
,p_column_alias=>'ID_VISITANTE'
,p_column_display_sequence=>20
,p_column_heading=>'Nombre del Visitante'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(26179485494677374482)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(29597254649719878840)
,p_query_column_id=>2
,p_column_alias=>'MOTIVO_VISITANTE'
,p_column_display_sequence=>40
,p_column_heading=>'Motivo de Visita'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(23207535598341038245)
,p_name=>'P25_ID_CASO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(23207535432458038244)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(29597253856662878832)
,p_name=>'P25_ID_TIPO_AFECTADO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(23207535432458038244)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select A.ID_TIPO_AFECTADO',
'  from AFECTADO A',
'  inner join AFECTADO_X_CASO F',
'  on A.ID_AFECTADO = F.ID_AFECTADO',
'  where F.ID_CASO = :P25_ID_CASO;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.component_end;
end;
/
