prompt --application/pages/page_00110
begin
--   Manifest
--     PAGE: 00110
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.2'
,p_default_workspace_id=>8391952292696292789
,p_default_application_id=>74555
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BANCHONWORKSPACE'
);
wwv_flow_api.create_page(
 p_id=>110
,p_user_interface_id=>wwv_flow_api.id(26165657796355479380)
,p_name=>unistr('Acerca de esta Aplicaci\00F3n')
,p_alias=>'HELP'
,p_step_title=>unistr('Acerca de esta Aplicaci\00F3n')
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_api.id(31606097764485130249)
,p_protection_level=>'C'
,p_help_text=>unistr('Desde esta p\00E1gina se puede acceder a todo el texto de ayuda de la aplicaci\00F3n. Los enlaces de la regi\00F3n "Documentaci\00F3n" ofrecen una explicaci\00F3n mucho m\00E1s detallada de las funciones y la funcionalidad de la aplicaci\00F3n.')
,p_last_updated_by=>'HBANCHONG@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20210904040035'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(29597254955847878843)
,p_name=>'&APP_NAME.'
,p_template=>wwv_flow_api.id(26165558220393479310)
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'t-HeroRegion--featured'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-AVPList--rightAligned'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select aa.version app_version,',
'       to_char(aa.pages,''999G999G990'') pages,',
'       ''UCA'' vendor',
'from apex_applications aa',
'where aa.application_id = :APP_ID'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(26165601117775479332)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(29597255049526878844)
,p_query_column_id=>1
,p_column_alias=>'APP_VERSION'
,p_column_display_sequence=>10
,p_column_heading=>unistr('Versi\00F3n de la Aplicaci\00F3n')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(29597255150094878845)
,p_query_column_id=>2
,p_column_alias=>'PAGES'
,p_column_display_sequence=>20
,p_column_heading=>unistr('P\00E1ginas contenidas')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(29597255285552878846)
,p_query_column_id=>3
,p_column_alias=>'VENDOR'
,p_column_display_sequence=>30
,p_column_heading=>'Implementado por:'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(31606098464914130257)
,p_plug_name=>unistr('Acerca de la P\00E1gina')
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h1:t-ContentBlock--lightBG'
,p_plug_template=>wwv_flow_api.id(26165555890829479309)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<p>Sistema de Registros de Casos e Incidentes dentro de la Universidad ''Jos\00E9 Sime\00F3n Ca\00F1as''. </p> <br>'),
'',
'<p>Desarrollado como proyecto final de tesis, por los siguientes estudiantes: </p>',
'<dl>',
unistr('    <dt><strong>Pedro Ren\00E9 G\00F3mez Fuentes</strong>&emsp;&emsp;&emsp;pedrodeveloper14@gmail.com</dt>      '),
unistr('    <dt><strong>Carmen Mar\00EDa Solano Garc\00EDa</strong>&emsp;&emsp;&emsp;carmensolano0516@gmail.com</dt>'),
unistr('    <dt><strong>Henry Luis Banch\00F3n Gallardo</strong>&emsp;&emsp;&emsp;hbanchon.dev@gmail.com</dt>')))
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.component_end;
end;
/
