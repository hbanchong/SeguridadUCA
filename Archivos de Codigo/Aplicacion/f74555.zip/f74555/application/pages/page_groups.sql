prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 74555
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.2'
,p_default_workspace_id=>8391952292696292789
,p_default_application_id=>74555
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BANCHONWORKSPACE'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(26165660804734479398)
,p_group_name=>unistr('Administraci\00F3n')
);
wwv_flow_api.component_end;
end;
/
