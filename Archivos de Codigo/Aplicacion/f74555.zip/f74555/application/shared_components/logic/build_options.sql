prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 74555
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.2'
,p_default_workspace_id=>8391952292696292789
,p_default_application_id=>74555
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BANCHONWORKSPACE'
);
wwv_flow_api.create_build_option(
 p_id=>wwv_flow_api.id(30712899619822133670)
,p_build_option_name=>unistr('Funci\00F3n: Control de Acceso')
,p_build_option_status=>'INCLUDE'
,p_feature_identifier=>'APPLICATION_ACCESS_CONTROL'
,p_build_option_comment=>unistr('Incorpore la autenticaci\00F3n de usuarios basada en roles en la aplicaci\00F3n y gestione las asignaciones de nombres de usuario a roles de la aplicaci\00F3n.')
);
wwv_flow_api.create_build_option(
 p_id=>wwv_flow_api.id(31606097764485130249)
,p_build_option_name=>unistr('Funci\00F3n: Acerca de la P\00E1gina')
,p_build_option_status=>'INCLUDE'
,p_feature_identifier=>'APPLICATION_ABOUT_PAGE'
,p_build_option_comment=>unistr('P\00E1gina Acerca de esta aplicaci\00F3n.')
);
wwv_flow_api.component_end;
end;
/
