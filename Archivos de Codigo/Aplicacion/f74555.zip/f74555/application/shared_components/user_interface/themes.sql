prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 74555
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.2'
,p_default_workspace_id=>8391952292696292789
,p_default_application_id=>74555
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BANCHONWORKSPACE'
);
wwv_flow_api.create_theme(
 p_id=>wwv_flow_api.id(26165636081916479367)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_ui_type_name=>'DESKTOP'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_api.id(26165529286396479294)
,p_default_dialog_template=>wwv_flow_api.id(26165524910282479292)
,p_error_template=>wwv_flow_api.id(26165517043990479287)
,p_printer_friendly_template=>wwv_flow_api.id(26165529286396479294)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_api.id(26165517043990479287)
,p_default_button_template=>wwv_flow_api.id(26165633243575479353)
,p_default_region_template=>wwv_flow_api.id(26165568079583479315)
,p_default_chart_template=>wwv_flow_api.id(26165568079583479315)
,p_default_form_template=>wwv_flow_api.id(26165568079583479315)
,p_default_reportr_template=>wwv_flow_api.id(26165568079583479315)
,p_default_tabform_template=>wwv_flow_api.id(26165568079583479315)
,p_default_wizard_template=>wwv_flow_api.id(26165568079583479315)
,p_default_menur_template=>wwv_flow_api.id(26165577416394479319)
,p_default_listr_template=>wwv_flow_api.id(26165568079583479315)
,p_default_irr_template=>wwv_flow_api.id(26165566175515479314)
,p_default_report_template=>wwv_flow_api.id(26165598113353479330)
,p_default_label_template=>wwv_flow_api.id(26165630668626479351)
,p_default_menu_template=>wwv_flow_api.id(26165634670469479353)
,p_default_calendar_template=>wwv_flow_api.id(26165634734709479355)
,p_default_list_template=>wwv_flow_api.id(26165614571962479340)
,p_default_nav_list_template=>wwv_flow_api.id(26165626373035479348)
,p_default_top_nav_list_temp=>wwv_flow_api.id(26165626373035479348)
,p_default_side_nav_list_temp=>wwv_flow_api.id(26165620913610479345)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_api.id(26165537923214479300)
,p_default_dialogr_template=>wwv_flow_api.id(26165536920310479299)
,p_default_option_label=>wwv_flow_api.id(26165630668626479351)
,p_default_required_label=>wwv_flow_api.id(26165632026825479352)
,p_default_page_transition=>'NONE'
,p_default_popup_transition=>'NONE'
,p_default_navbar_list_template=>wwv_flow_api.id(26165620508666479344)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#IMAGE_PREFIX#themes/theme_42/21.1/')
,p_files_version=>82
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_IMAGES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_IMAGES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_api.component_end;
end;
/
