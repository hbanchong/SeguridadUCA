prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 74555
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.2'
,p_default_workspace_id=>8391952292696292789
,p_default_application_id=>74555
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BANCHONWORKSPACE'
);
wwv_flow_api.create_theme_style(
 p_id=>wwv_flow_api.id(26165635051811479364)
,p_theme_id=>42
,p_name=>'Redwood Light'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#',
'#THEME_IMAGES#css/Redwood#MIN#.css?v=#APEX_VERSION#'))
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_IMAGES#less/theme/Redwood-Theme.less'
,p_theme_roller_output_file_url=>'#THEME_IMAGES#css/Redwood-Theme#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>2596426436825065489
);
wwv_flow_api.create_theme_style(
 p_id=>wwv_flow_api.id(26165635282321479364)
,p_theme_id=>42
,p_name=>'Vita'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_IMAGES#less/theme/Vita.less'
,p_theme_roller_output_file_url=>'#THEME_IMAGES#css/Vita#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>2719875314571594493
);
wwv_flow_api.create_theme_style(
 p_id=>wwv_flow_api.id(26165635421785479364)
,p_theme_id=>42
,p_name=>'Vita - Dark'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_IMAGES#less/theme/Vita-Dark.less'
,p_theme_roller_output_file_url=>'#THEME_IMAGES#css/Vita-Dark#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>3543348412015319650
);
wwv_flow_api.create_theme_style(
 p_id=>wwv_flow_api.id(26165635623632479364)
,p_theme_id=>42
,p_name=>'Vita - Red'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_IMAGES#less/theme/Vita-Red.less'
,p_theme_roller_output_file_url=>'#THEME_IMAGES#css/Vita-Red#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>1938457712423918173
);
wwv_flow_api.create_theme_style(
 p_id=>wwv_flow_api.id(26165635870608479364)
,p_theme_id=>42
,p_name=>'Vita - Slate'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_IMAGES#less/theme/Vita-Slate.less'
,p_theme_roller_output_file_url=>'#THEME_IMAGES#css/Vita-Slate#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>3291983347983194966
);
wwv_flow_api.create_theme_style(
 p_id=>wwv_flow_api.id(29374642702491966964)
,p_theme_id=>42
,p_name=>'UCA'
,p_is_current=>true
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_IMAGES#less/theme/Vita.less'
,p_theme_roller_config=>'{"classes":[],"vars":{"@l_Button-Hot-BG":"#4d5a91","@l_Button-Hot-Text":"#ffffff","@g_Form-BorderRadius":"4px","@g_Header-BG":"#1e3163","@g_Header-FG":"#ffffff","@g_Accent-BG":"#1e3163","@g_Nav-Accent-BG":"#4d5a91","@g_Nav-Accent-FG":"#ffffff","@g_Na'
||'v-BG":"#000938","@g_Nav-FG":"#dadada","@g_Nav-Active-BG":"#4d5a91","@g_Nav-Active-FG":"#f2f2f2","@g_Body-BG":"#fdfdfd","@g_Body-Text":"#000000","@g_Nav-Icon":"#fdfdfd","@g_Nav-Icon-Active":"#f2f2f2","@g_Actions-Col-BG":"#f9f9f9","@g_Actions-Col-Text"'
||':"#000000","@g_Button-BG":"#1e3163","@g_Button-Text":"#e5e1e1","@Side-Exp":"260px","@irrBg":"#ffffff","@g_Form-Item-BG":"#ffffff","@g_Form-Item-FG":"#202020","@l_Button-Simple-BG":"#ffffff","@l_Button-Simple-Text":"#404040","@g_Region-Header-BG":"#ff'
||'ffff","@g_Region-Header-FG":"#262626","@g_Region-BG":"#ffffff","@g_Region-FG":"#262626","@g_Disabled-BG":"#707070","@g_Disabled-FG":"#ffffff","@g_NavBarMenu-BG":"#ffffff","@g_NavBarMenu-FG":"#262626","@g_Body-Title-BG":"#ffffff","@g_Body-Title-FG":"#'
||'000000"},"customCSS":".t-PageBody--Login {\n    background-color: #4d5a91;\n}\n\n.footer-apex {font-size: 11px; line-height: 16px; display: inline-block; vertical-align: top;}\n.footer-apex .fa.fa-heart { vertical-align: top; font-size: 10px; \n    l'
||'ine-height: 16px; width: 16px; text-align: center; \n    transition: color 1s ease; }\n.footer-apex:hover .fa.fa-heart { color: #FF0000; animation: pulse 1s infinite; }\n \n@keyframes pulse {\n    0% { transform: scale(0.9); }\n    70% { transform: s'
||'cale(1.25); }\n    100% { transform: scale(0.9); }\n}\n","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_IMAGES#29374642702491966964.css'
,p_theme_roller_read_only=>false
);
wwv_flow_api.component_end;
end;
/
