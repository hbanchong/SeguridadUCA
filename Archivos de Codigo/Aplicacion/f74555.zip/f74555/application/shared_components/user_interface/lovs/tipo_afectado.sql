prompt --application/shared_components/user_interface/lovs/tipo_afectado
begin
--   Manifest
--     TIPO_AFECTADO
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.2'
,p_default_workspace_id=>8391952292696292789
,p_default_application_id=>74555
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BANCHONWORKSPACE'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(26173362177025742007)
,p_lov_name=>'TIPO_AFECTADO'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'TIPO_AFECTADO'
,p_return_column_name=>'ID_TIPO_AFECTADO'
,p_display_column_name=>'NOMBRE_TIPO_AFECTADO'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'NOMBRE_TIPO_AFECTADO'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
