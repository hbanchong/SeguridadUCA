prompt --application/shared_components/user_interface/lovs/empleados
begin
--   Manifest
--     EMPLEADOS
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.2'
,p_default_workspace_id=>8391952292696292789
,p_default_application_id=>74555
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BANCHONWORKSPACE'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(26179496607222377944)
,p_lov_name=>'EMPLEADOS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ID_EMPLEADO, NOMBRE_EMPLEADO || '' '' || APELLIDO_EMPLEADO as "Nombre de empleado"',
'FROM EMPLEADO;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'EMPLEADO'
,p_return_column_name=>'ID_EMPLEADO'
,p_display_column_name=>'Nombre de empleado'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
