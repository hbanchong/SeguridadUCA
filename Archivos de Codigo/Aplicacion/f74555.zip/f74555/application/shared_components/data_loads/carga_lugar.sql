prompt --application/shared_components/data_loads/carga_lugar
begin
--   Manifest
--     DATA LOAD: Carga-Lugar
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.2'
,p_default_workspace_id=>8391952292696292789
,p_default_application_id=>74555
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BANCHONWORKSPACE'
);
wwv_flow_api.create_data_profile(
 p_id=>wwv_flow_api.id(30485056856465851522)
,p_name=>'Carga-Lugar'
,p_format=>'JSON'
,p_encoding=>'utf-8'
);
wwv_flow_api.create_data_profile_col(
 p_id=>wwv_flow_api.id(30485057143975851577)
,p_data_profile_id=>wwv_flow_api.id(30485056856465851522)
,p_name=>'NOMBRE_LUGAR'
,p_sequence=>1
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>250
,p_selector=>'name'
);
wwv_flow_api.create_data_profile_col(
 p_id=>wwv_flow_api.id(30485057459441851577)
,p_data_profile_id=>wwv_flow_api.id(30485056856465851522)
,p_name=>'GEOMETRIA'
,p_sequence=>2
,p_column_type=>'DATA'
,p_data_type=>'SDO_GEOMETRY'
,p_selector=>'geometry'
);
wwv_flow_api.create_load_table(
 p_id=>wwv_flow_api.id(30485057671087851578)
,p_name=>'Carga-Lugar'
,p_static_id=>'Carga_Lugar'
,p_target_type=>'TABLE'
,p_table_name=>'LUGAR'
,p_data_profile_id=>wwv_flow_api.id(30485056856465851522)
,p_loading_method=>'APPEND'
,p_commit_interval=>200
,p_error_handling=>'ABORT'
,p_skip_validation=>'N'
);
wwv_flow_api.component_end;
end;
/
