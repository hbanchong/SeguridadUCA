prompt --application/shared_components/credentials/google_credentials
begin
--   Manifest
--     CREDENTIAL: Google Credentials
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.2'
,p_default_workspace_id=>8391952292696292789
,p_default_application_id=>74555
,p_default_id_offset=>0
,p_default_owner=>'WKSP_BANCHONWORKSPACE'
);
wwv_flow_api.create_credential(
 p_id=>wwv_flow_api.id(31608105895794811244)
,p_name=>'Google Credentials'
,p_static_id=>'apex_social_login'
,p_authentication_type=>'OAUTH2_CLIENT_CREDENTIALS'
,p_prompt_on_install=>true
);
wwv_flow_api.component_end;
end;
/
